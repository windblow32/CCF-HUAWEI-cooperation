class config:
    s_RMSE = 1
    s_Median_AE = 0.9
    s_Mean_AE = 0.9

    def __init__(self):
        i = 0
    def load(self):

        return self.s_RMSE, self.s_Median_AE, self.s_Mean_AE


